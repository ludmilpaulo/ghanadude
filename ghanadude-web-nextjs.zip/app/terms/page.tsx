export default function Page(){
  return <section className="container py-10"><h1 className="text-2xl font-bold capitalize">terms</h1><p className="mt-2 text-gray-600">Content coming soon.</p></section>
}
